﻿using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using NUnit.Framework;
using System;

namespace AmazonUS
{
    public class OpenAmazon

    {
        [Test]
        public static void Main(String[] args)
        {
            IWebDriver driver;
            // Declaration and instantiation of objects		
            driver = new FirefoxDriver();
            driver.Url = "https://amazon.com";

            // Finding the search button		
            WebElement textbox = (WebElement)driver.FindElement(By.Id("twotabsearchtextbox"));

            // Searching for "Shoes"		
            textbox.SendKeys("shoes");
            textbox.Click();
            WebElement searchbutton = (WebElement)driver.FindElement(By.Id("nav-search-submit-button"));
            searchbutton.Click();

            // Closing the browser
            driver.Close();
        }
    }
}